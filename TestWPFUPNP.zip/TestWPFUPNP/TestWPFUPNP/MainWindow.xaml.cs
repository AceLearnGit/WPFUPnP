﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace TestWPFUPNP
{
    /// <summary>
    /// MainWindow.xaml 的交互逻辑
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            //发现设备
            DiscoverSSNPDevice();
            //投屏
            SetAVTransportURI();
        }

        UdpClient udpClient = new UdpClient(AddressFamily.InterNetwork);
        /// <summary>
        /// 组播地址
        /// </summary>
        IPEndPoint multicastAddress = new IPEndPoint(IPAddress.Parse("239.255.255.250"), 1900);

        bool listenSSDP = true;

        /// <summary>
        /// 发送 发现ssdp设备 的消息
        /// </summary>
        private async void DiscoverSSNPDevice()
        {
            //urn:schemas-upnp-org:service:AVTransport:1 代表投屏
            string str = "M-SEARCH * HTTP/1.1\r\n" +
                         "HOST: 239.255.255.250:1900\r\n" +
                         "MAN:\"ssdp:discover\"\r\n" +
                         "MX:5\r\n" +
                         "ST:urn:schemas-upnp-org:service:AVTransport:1\r\n\r\n";
            byte[] data = Encoding.UTF8.GetBytes(str);
            //udpClient.send(data, data.Length, multicastAddress);
            await udpClient.SendAsync(data, data.Length, multicastAddress);
            ListenUdpMsg();
        }

        /// <summary>
        /// 远程主机地址
        /// </summary>
        IPEndPoint remoteIPEndPoint = null;
        /// <summary>
        /// 接收UDP消息（此处主要为接受ssdp:discover消息的回复）
        /// </summary>
        private void ListenUdpMsg()
        {

            byte[] data = udpClient.Receive(ref remoteIPEndPoint);
            string responseStr = Encoding.UTF8.GetString(data);
            Debug.WriteLine(remoteIPEndPoint + ":" + responseStr);
            //TODO:xml解析，拿到我们要用的AVTransport服务节点

            //以小米盒子4为例
            //string str = @"
            //                <service>
            //                    <serviceType>urn:schemas-upnp-org:service:AVTransport:1</serviceType>
            //                    <serviceId>urn:upnp-org:serviceId:AVTransport</serviceId>
            //                    <SCPDURL>/dlna/Render/AVTransport_scpd.xml</SCPDURL>
            //                    <controlURL>_urn:schemas-upnp-org:service:AVTransport_control</controlURL>
            //                    <eventSubURL>_urn:schemas-upnp-org:service:AVTransport_event</eventSubURL>
            //                </service>";

            //其中 SCPDURL节点对应的值为服务描述文件地址，我们应该继续继续该描述文件，并利用解析到的action控制设备

        }

        /// <summary>
        /// 小米盒子4回应ssdp:discover消息时描述文件基地址
        /// </summary>
        private static string URLBase = "http://172.20.10.3:49152/";
        /// <summary>
        /// 投屏使用的服务类型
        /// </summary>
        private static string Casting_serviceType = "urn:schemas-upnp-org:service:ConnectionManager:1";
        private static string Casting_serviceId = "urn:upnp-org:serviceId:ConnectionManager";

        /// <summary>
        /// 投屏所使用的服务描述文件地址
        /// </summary>
        private static string Casting_SCPDURL = "/dlna/Render/AVTransport_scpd.xml";
        /// <summary>
        /// 向服务发出控制消息的URL
        /// </summary>
        private static string Casting_controlURL = "_urn:schemas-upnp-org:service:ConnectionManager_control";
        private static string Casting_eventSubURL = "_urn:schemas-upnp-org:service:ConnectionManager_event";

        private string GetServiceDescUrl(string descXml, string serviceType)
        {
            //假设descXml为小米盒子4回应ssdp:discover消息中附带的设备描述信息
            //以向小米盒子4投屏为例，我们使用的serviceType为 urn:schemas-upnp-org:service:ConnectionManager:1
            //TODO:进行xml解析，拿到serviceType为urn:schemas-upnp-org:service:ConnectionManager:1的节点信息
            return Casting_SCPDURL;

        }

        /// <summary>
        /// 获取AVTransportService的描述文件
        /// </summary>
        /// <param name="serviceDescUrl"></param>
        private string GetAVTransportServiceDes(string serviceDescUrl)
        {
            //假设serviceDescUrl为小米盒子4投屏服务的描述文件地址（实际为基地址和SCPDURL的拼接，注意/）
            //这里我的地址为 http://172.20.10.3:49152/dlna/Render/AVTransport_scpd.xml
            string str = "GET " + URLBase.Remove(URLBase.Length - 1) + Casting_SCPDURL + " HTTP/1.1\r\n" +
                             "HOST:" + remoteIPEndPoint.Address + ":" + remoteIPEndPoint.Port + "\r\n" +
                             "ACCEPT-LANGUAGE: \r\n\r\n",
                   result = "";
            byte[] data = Encoding.UTF8.GetBytes(str);
            TcpClient tcpClient = new TcpClient(AddressFamily.InterNetwork);
            NetworkStream networkStream = null;
            try
            {
                tcpClient.Connect(remoteIPEndPoint);
                networkStream = tcpClient.GetStream();
                networkStream.Write(data, 0, data.Length);
                //Thread.Sleep(100);
                int ReadSize = 2048;
                byte[] buff = new byte[ReadSize], readBuff;
                str = "";
                while (ReadSize == 2048)
                {
                    ReadSize = networkStream.Read(buff, 0, buff.Length);
                    readBuff = new byte[ReadSize];
                    Array.Copy(buff, 0, readBuff, 0, ReadSize);
                    str += Encoding.UTF8.GetString(readBuff);
                }
                result = str.Substring(str.IndexOf("\r\n\r\n") + 4).Trim();
                while (result.Substring(result.Length - 2) == "\r\n" || result.Substring(result.Length - 2) == Encoding.Default.GetString(new byte[2] { 0, 0 }))
                {
                    result = result.Substring(0, result.Length - 2);
                }
            }
            catch { }
            finally
            {
                if (networkStream != null)
                {
                    networkStream.Close();
                    networkStream.Dispose();
                }
                if (tcpClient != null)
                {
                    tcpClient.Close();
                }
            }
            //TODO:随后我们应进行xml解析，拿到我们投屏要使用的action信息，这里我们需要使用SetAVTransportURI
            return result;//AVTransport_scpd.xml文件中的内容
        }

        /// <summary>
        /// 被投屏的文件Url
        /// </summary>
        private string fileUrl = "https://www.baidu.com/img/baidu_resultlogo@2.png";//http://172.20.10.12:9000/file_video/ladybug.wmv

        /// <summary>
        /// 动作名称，投屏本质本质为调用该方法
        /// </summary>
        private static string SetAVTransportURIStr = "SetAVTransportURI";
        /// <summary>
        /// 调用SetAVTransportURI action进行投屏
        /// </summary>
        private void SetAVTransportURI()
        {
            string soapData = $"<u:{SetAVTransportURIStr} xmlns:u=\"{Casting_serviceType}\">" +
                    "<InstanceID>0</InstanceID>" +
                    "<CurrentURI>" + fileUrl + "</CurrentURI>" +
                    "<CurrentURIMetaData/>" +
                $"</u:{Casting_serviceId}>";

            string soap = "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">" +
                            "<s:Body>" + soapData + "</s:Body>" +
                          "</s:Envelope>";

            //URLBase + Casting_controlURL=http://172.20.10.3:49152/_urn:schemas-upnp-org:service:AVTransport_control
            string strData = "POST " + URLBase + Casting_controlURL + " HTTP/1.1\r\n" +
                             "HOST: " + remoteIPEndPoint + "\r\n" +
                             "Content-Length: " + Encoding.UTF8.GetBytes(soap).Length.ToString() + "\r\n" +
                             "CONTENT-TYPE: text/xml; charset=\"utf-8\"\r\n" +
                             "SOAPACTION: \"" + Casting_serviceId + "#" + SetAVTransportURIStr + "\"\r\n\r\n" + soap;

            byte[] data = Encoding.Default.GetBytes(strData);
            TcpClient tcpClient = new TcpClient(AddressFamily.InterNetwork);
            NetworkStream networkStream = null;
            try
            {
                tcpClient.Connect(remoteIPEndPoint);
                networkStream = tcpClient.GetStream();
                networkStream.Write(data, 0, data.Length);
                byte[] buffer = new byte[4096], readBuff;
                int ReadSize = networkStream.Read(buffer, 0, buffer.Length);
                readBuff = new byte[ReadSize];
                Array.Copy(buffer, 0, readBuff, 0, ReadSize);
                strData = Encoding.Default.GetString(readBuff);//调用结果，这里就不分析了
            }
            catch (Exception ex)
            {

            }
            finally
            {
                if (networkStream != null)
                {
                    networkStream.Close();
                }
                tcpClient.Close();
            }
        }
    }
}
